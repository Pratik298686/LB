#include<stdio.h>       // Used for IO functions

int Addition(int,int);    // Function prototype
