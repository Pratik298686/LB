#include"Header.h"

////////////////////////////////////////////////////////////////////
//
//  Function Name :         Addition
//  Input :                      Integrer, Interger
//  Output :                    Interger
//  Description:               It is used to perform addition
//  Date :                       14 July 2020
//  Author name :            Piyush Manohar Khairnar
//
///////////////////////////////////////////////////////////////////

int Addition(
                    int iValue1,        // First number
                    int iValue2         // Second numbber
                )
{
    int iAns = 0;                      // Local variable to store addistion
    
    iAns = iValue1 + iValue2;
    
    return iAns;                        // Return the addition
}
